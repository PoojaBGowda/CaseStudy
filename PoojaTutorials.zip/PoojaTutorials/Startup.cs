﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PoojaTutorials.Startup))]
namespace PoojaTutorials
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
