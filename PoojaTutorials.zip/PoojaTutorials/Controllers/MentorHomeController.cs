﻿using PoojaTutorials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace PoojaTutorials.Controllers
{
   
    public class MentorHomeController : Controller
    {
        Self_Learning_TutorialsEntities5 sf = new Self_Learning_TutorialsEntities5();
        Self_Learning_TutorialsEntities1 db = new Self_Learning_TutorialsEntities1();
        // GET: MentorHome
        
        public ActionResult Forums()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    var result = sf.ps_Getquestions().ToList();
                    List<Forums> model = new List<Forums>();
                    foreach (var item in result)
                    {
                        model.Add(new Forums
                        {
                            Questions = item.Questions,
                            postedBy = item.Posted_by,
                            Question_Id = item.QId
                        });

                    }
                    return View(model);
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");
            }
        }


        [HttpPost]
        public ActionResult MentorAnswer(System.Web.Mvc.FormCollection form, int id)
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    string a = Session["Email"].ToString();
                    var mentor = db.tblMentors.Where(x => x.Email == a).FirstOrDefault();
                    tblAForum quest = new tblAForum();
                    quest.QId = id;
                    quest.Answered_by = mentor.Name;
                    quest.Answers = form["AnswerBox"].ToString();
                    db.tblAForums.Add(quest);
                    db.SaveChanges();
                    return Content("Question has been submitted successfully");
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");

            }
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult ChangePwd()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");

            }
        }

        [HttpPost]
        public ActionResult ChangePwd(Change ch)
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    if (ModelState.IsValid)
                    {
                        var user = db.tblUsers.Where(x => x.Password == ch.OldPassword && x.Email == ch.Email).FirstOrDefault();
                        if (user != null)
                        {
                            user.Password = ch.NewPassword;
                            db.SaveChanges();
                            return RedirectToAction("Login", "Login");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid  Credentials!");
                            return View();
                        }
                    }
                    else
                        return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");

            }
        }

        public ActionResult EditProfile()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");

            }
        }

        [HttpPost]
        public ActionResult EditProfile(MentorEdit m1)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (Session["Email"].ToString() != null)
                    {

                        var emailid = Session["Email"].ToString();
                        var mentor = db.tblMentors.Where(m => m.Email == emailid).FirstOrDefault();
                        if (mentor != null)
                        {
                            if (m1.Email != null)
                                mentor.Email = m1.Email;
                            if (m1.PhoneNum != null)
                                mentor.PhoneNum = m1.PhoneNum;
                            if (m1.Technology != null)
                                mentor.Technology = m1.Technology;
                            if (m1.Experience != null)
                                mentor.Experience = (int)m1.Experience;
                            db.SaveChanges();
                            MessageBox.Show("Details have been submitted successfully");
                            return View();
                        }
                        else
                            return RedirectToAction("Forums", "MentorHome");
                    }
                    else
                        return RedirectToAction("Login", "Login");
                }
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction("Login", "Login");

            }
        }



    }
}
