﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PoojaTutorials.Models
{
    public class Mentor
    {
        public int MentorId { get; set; }
        [Required]
        [MinLength(4)]
        [MaxLength(20)]
        [RegularExpression(@"^[a-zA-Z][a-zA-Z\\s ]+$", ErrorMessage = "Enter the valid name")]
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        [Remote("doesEmailExist", "MentorRegister", HttpMethod = "Post", ErrorMessage = "This Email is registered by another user. Please try with another Email.")]
        public string Email { get; set; }
        [Required]
        [Phone]
        [Display(Name = "PhoneNum")]
        [RegularExpression(@"^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$", ErrorMessage ="Invalid Mobile number")]
        public string PhoneNum { get; set; }
        [Required]
        [Display(Name = "Experience")]
        public int Experience { get; set; }
        [Required]
        [Display(Name = "Technology")]
        public string Technology { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Password must be 8 char long.")]
        public string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        [Display(Name = "ConfirmPassword")]
        public string ConfirmPassword { get; set; }
        public int RoleId { get; set; }
        public System.DateTime Mentor_Timestamp { get; set; }
    }
}